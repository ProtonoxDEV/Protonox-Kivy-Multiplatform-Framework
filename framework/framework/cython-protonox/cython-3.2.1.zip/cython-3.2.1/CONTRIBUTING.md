See [docs/CONTRIBUTING.rst](docs/CONTRIBUTING.rst).
