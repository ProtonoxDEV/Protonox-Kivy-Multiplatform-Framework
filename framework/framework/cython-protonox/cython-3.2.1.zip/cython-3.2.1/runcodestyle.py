if __name__ == "__main__":
    import runtests

    runtests.TestCodeFormat('.').runTest()
